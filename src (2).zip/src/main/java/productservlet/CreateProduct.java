/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package productservlet;

import dao.ProductDAO;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Date;
import java.time.LocalDate;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import model.Message;
import model.Product;

/**
 *
 * @author nguye
 */
@WebServlet(name = "CreateProduct", urlPatterns = {"/createproduct"})
@MultipartConfig
public class CreateProduct extends HttpServlet {

    private static final String UPLOAD_DIRECTORY = "home/image";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet CreateProduct</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet CreateProduct at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String type = request.getParameter("type");
        String id = request.getParameter("id");

        request.setAttribute("type", type);
        request.setAttribute("id", id);

        request.getRequestDispatcher("home/createproduct.jsp").forward(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String idw = request.getParameter("id");
        
        String type = request.getParameter("type");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        int hero =Integer.parseInt(request.getParameter("hero"));
        int skin = Integer.parseInt(request.getParameter("skin"));
        String rank = request.getParameter("rank");
        double price =Double.valueOf(request.getParameter("price"));
        String name = request.getParameter("name");

        InputStream inputStream = null; // Input stream of the upload file

        // Obtains the upload file part in this multipart request
        Part filePart = request.getPart("file");
        String fileName = getFileName(filePart);
        if (filePart != null) {
            // Obtains input stream of the upload file
            inputStream = filePart.getInputStream();
        } else {
            // Xử lý khi không có file được tải lên
            response.getWriter().println("No file uploaded!");
        }

        // Đường dẫn đến thư mục lưu trữ tệp
        String applicationPath = getServletContext().getRealPath("");
        String uploadFilePath = applicationPath + File.separator + UPLOAD_DIRECTORY;

        // Tạo thư mục nếu nó chưa tồn tại
        File uploadDir = new File(uploadFilePath);
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }

        // Đường dẫn lưu trữ tệp
        String filePath = uploadFilePath + File.separator + fileName;

        // Lưu tệp vào thư mục
        try (FileOutputStream outputStream = new FileOutputStream(filePath)) {
            int read;
            final byte[] bytes = new byte[1024];
            while ((read = inputStream.read(bytes)) != -1) {
                outputStream.write(bytes, 0, read);
            }

        }
        
        Product prd= new Product();
        prd.setType(type);
        prd.setUsername(username);
        prd.setPassword(password);
        prd.setHero(hero);
        prd.setSkin(skin);
        prd.setRank(rank);
        prd.setPrice(price);
        prd.setCreated_at(Date.valueOf(LocalDate.now()));
        prd.setName(name);
        prd.setImage(filePart.getSubmittedFileName());
        
        ProductDAO prdao = new ProductDAO();
        prdao.addProduct(prd);
        
        
        // log
        Message mes = new Message();
        mes.setMessage("You have just created a new account with name: "+prd.getName()+" |" +"Created_At: "+Date.valueOf(LocalDate.now()));
        mes.setType("CreateProduct");
        prdao.addMessage(mes);
        
         response.sendRedirect(request.getContextPath()+"/listpage?type="+type+"&&id="+idw);

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String getFileName(Part part) {
        if (part == null) {
            return null; // Hoặc xử lý theo cách khác nếu part là null
        }
        String contentDisp = part.getHeader("content-disposition");
        String[] items = contentDisp.split(";");
        for (String s : items) {
            if (s.trim().startsWith("filename")) {
                return s.substring(s.indexOf("=") + 2, s.length() - 1);
            }
        }
        return "";
    }
}
