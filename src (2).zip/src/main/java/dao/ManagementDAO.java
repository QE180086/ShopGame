/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author nguye
 */
public class ManagementDAO {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public int countListName() {
        String sql = "SELECT COUNT(*) FROM listname  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int countProduct() {
        String sql = "SELECT COUNT(*) FROM product  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int minHero() {
        String sql = "SELECT Min(p.hero) FROM product p  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int maxHero() {
        String sql = "SELECT Max(p.hero) FROM product p  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int minskin() {
        String sql = "SELECT Min(p.skin) FROM product p  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int maxSkin() {
        String sql = "SELECT Max(p.skin) FROM product p  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int minPrice() {
        String sql = "SELECT Min(p.price) FROM product p  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public int maxPrice() {
        String sql = "SELECT Max(p.price) FROM product p  ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }
    
        public int numUser() {
        String sql = "SELECT Count(*) FROM users   ";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

}
