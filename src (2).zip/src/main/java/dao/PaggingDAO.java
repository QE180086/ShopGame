/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import model.Product;

/**
 *
 * @author nguye
 */
public class PaggingDAO {
    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    
    
    public List<Product> getProductPagging(String type,int index,int numrecord){
        List<Product> products = new ArrayList<>();
        String sql="SELECT * FROM product where product.type = ? LIMIT ? , ?";
        
         try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            ps.setString(1, type);
            ps.setInt(2, (index-1)*numrecord);
            ps.setInt(3, numrecord);
            
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                products.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getDouble(8),
                        rs.getString(9),
                        rs.getDate(10),
                        rs.getString(11))
                );

            }

        } catch (Exception e) {
        }

        
        return products;
    }
    
}
