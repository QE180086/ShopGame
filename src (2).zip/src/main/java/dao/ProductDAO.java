/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectDB;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.ListName;
import model.Message;
import model.Product;

/**
 *
 * @author nguye
 */
public class ProductDAO {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Product> getProductByType(String type, int index) {
        String sql = "SELECT * FROM product where product.type = ? LIMIT ? , 2";
        List<Product> products = new ArrayList<>();
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            ps.setString(1, type);
            ps.setInt(2, (index - 1) * 2);

            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                products.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getDouble(8),
                        rs.getString(9),
                        rs.getDate(10),
                        rs.getString(11))
                );

            }

        } catch (Exception e) {
        }
        return products;

    }

    public List<Product> getAllProductByType() {
        String sql = "SELECT * FROM product";
        List<Product> products = new ArrayList<>();
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                products.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getDouble(8),
                        rs.getString(9),
                        rs.getDate(10),
                        rs.getString(11))
                );

            }

        } catch (Exception e) {
        }
        return products;

    }

    public int countProduct(String type) {
        String sql = "SELECT count(*) FROM product where product.type =?";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            ps.setString(1, type);

            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);

            }

        } catch (Exception e) {
        }
        return 0;

    }

    public void addProduct(Product product) {
        String sql = "insert into product(type,username,password,hero,skin,rank,price,image,created_at,name) values(?,?,?,?,?,?,?,?,?,?)";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            ps.setString(1, product.getType());
            ps.setString(2, product.getUsername());
            ps.setString(3, product.getPassword());
            ps.setInt(4, product.getHero());
            ps.setInt(5, product.getSkin());
            ps.setString(6, product.getRank());
            ps.setDouble(7, product.getPrice());
            ps.setString(8, product.getImage());
            ps.setDate(9, Date.valueOf(LocalDate.now()));
            ps.setString(10, product.getName());

            ps.executeUpdate();

        } catch (Exception e) {
        }

    }

    public void deleteProduct(String id) {
        String sql = "DELETE FROM product WHERE product.id=?";

        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }

    public Product updateProduct(Product product) {
        String sql = "UPDATE product SET product.type =?,product.username =?,product.password =?,product.hero =?,product.skin =?,product.rank =?,product.price =?, product.image=?,product.name =? WHERE product.id=?";
        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, product.getType());
            ps.setString(2, product.getUsername());
            ps.setString(3, product.getPassword());
            ps.setInt(4, product.getHero());
            ps.setInt(5, product.getSkin());
            ps.setString(6, product.getRank());
            ps.setDouble(7, product.getPrice());
            ps.setString(8, product.getImage());
            ps.setString(9, product.getName());
            ps.setInt(10, product.getId());

            ps.executeUpdate();
        } catch (Exception e) {
        }

        return product;
    }

    public Product findProductById(String id) {

        String sql = "select * FROM product WHERE product.id=?";

        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getDouble(8),
                        rs.getString(9),
                        rs.getDate(10),
                        rs.getString(11)
                );

            }
        } catch (Exception e) {
        }
        return null;
    }

    public int count(String txtSearch) {
        String sql = "select count(*) from product where product.name like ?";

        try {
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + txtSearch + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {

        }
        return 0;

    }

    public List<Product> findByName(String txtSearch, String type) {
        List<Product> prd = new ArrayList<>();
        String sql = "select * FROM product WHERE product.name like ? and product.type like ?";

        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, "%" + txtSearch + "%");
            ps.setString(2, "%" + type + "%");
            rs = ps.executeQuery();
            while (rs.next()) {
                prd.add(new Product(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getInt(5),
                        rs.getInt(6),
                        rs.getString(7),
                        rs.getDouble(8),
                        rs.getString(9),
                        rs.getDate(10),
                        rs.getString(11))
                );

            }
        } catch (Exception e) {
        }
        return prd;
    }

    public void addMessage(Message mes) {
        String sql = "insert into message(message,type) values(?,?)";

        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            ps.setString(1, mes.getMessage());
            ps.setString(2, mes.getType());

            ps.executeUpdate();

        } catch (Exception e) {
        }
    }

    public List<Message> getMessage(int limit, int offset) {
        String sql = "SELECT * FROM message ORDER BY message.id DESC LIMIT ? OFFSET ?";
        List<Message> messages = new ArrayList<>();
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            // excute
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            rs = ps.executeQuery();
            while (rs.next()) {
                messages.add(new Message(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3))
                );

            }

        } catch (Exception e) {
        }
        return messages;

    }

    public int getMessageCount() {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM message";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

}
