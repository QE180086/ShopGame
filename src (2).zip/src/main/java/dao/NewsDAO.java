/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectDB;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.Post;

/**
 *
 * @author nguye
 */
public class NewsDAO {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public List<Post> getAllPost() {
        String sql = "SELECT * FROM post ";
        List<Post> posts = new ArrayList<>();
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                posts.add(new Post(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDate(4),
                        rs.getString(5),
                        rs.getString(6))
                );
            }

        } catch (Exception e) {
        }
        return posts;

    }

    public List<Post> getPost(int limit, int offset) {
        String sql = "SELECT * FROM post ORDER BY id DESC LIMIT ? OFFSET ?";
        List<Post> posts = new ArrayList<>();
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            ps.setInt(1, limit);
            ps.setInt(2, offset);
            rs = ps.executeQuery();
            while (rs.next()) {
                posts.add(new Post(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getDate(4),
                        rs.getString(5),
                        rs.getString(6))
                );
            }

        } catch (Exception e) {
        }
        return posts;
    }

    public int getPostCount() {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM post";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
    }

    public void addPost(Post post) {
        String sql = "insert into post(content,image,link,created_at,tiltle) values(?,?,?,?,?)";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            ps.setString(1, post.getContent());
            ps.setString(2, post.getImage());
            ps.setString(3, post.getLink());
            ps.setDate(4, Date.valueOf(LocalDate.now()));
            ps.setString(5, post.getTitle());
            ps.executeUpdate();

        } catch (Exception e) {
        }
    }
    
      public void deletePost(String id) {
        String sql = "DELETE FROM post WHERE post.id=?";

        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }
    
    
}
