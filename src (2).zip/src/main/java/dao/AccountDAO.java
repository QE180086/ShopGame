/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectDB;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import model.User;

/**
 *
 * @author nguye
 */
public class AccountDAO {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public void registerAccount(User user) {
        String sql = "insert into users(email,fullname,username,password,created_at) values(?,?,?,?,?)";

        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            ps.setString(1, user.getEmail());
            ps.setString(2, user.getFullname());
            ps.setString(3, user.getUsername());
            ps.setString(4, user.getPassword());
            ps.setDate(5, Date.valueOf(LocalDate.now()));

            ps.executeUpdate();

        } catch (Exception e) {
        }

    }
    public User checkRegister(String username) {
        String sql = "SELECT * FROM users u WHERE u.username=? ";

        try {
            con = new ConnectDB().condb();
            ps = con.prepareStatement(sql);
            ps.setString(1, username);
            

            rs = ps.executeQuery();
            while (rs.next()) {
                return new User(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getDate(6)
                );
            }

        } catch (Exception e) {

        }
        return null;

    }

    public User checkLogin(String username, String password) {
        String sql = "SELECT * FROM users u WHERE u.username=? AND u.password=?";

        try {
            con = new ConnectDB().condb();
            ps = con.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);

            rs = ps.executeQuery();
            while (rs.next()) {
                return new User(
                        rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3),
                        rs.getString(4),
                        rs.getString(5),
                        rs.getDate(6)
                );
            }

        } catch (Exception e) {

        }
        return null;

    }
//    
//    public User findUserById(int id){
//        String sql="SELECT * FROM USERs WHERE id=?";
//        
//        
//        
//    }

}
