/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectDB;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import model.ListName;

/**
 *
 * @author nguye
 */
public class ListNameDAO {

    Connection con = null;
    PreparedStatement ps = null;
    ResultSet rs = null;

    public void addListName(ListName listName) {
        String sql = "insert into listname(type,image) values(?,?)";
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);

            ps.setString(1, listName.getType());
            ps.setString(2, listName.getImage());

            ps.executeUpdate();

        } catch (Exception e) {
        }

    }

    public List<ListName> getListName() {
        String sql = "SELECT * FROM listname ";
        List<ListName> listname = new ArrayList<>();
        try {
            // connect
            con = new ConnectDB().condb();
            // write sql
            ps = con.prepareStatement(sql);
            // excute
            rs = ps.executeQuery();
            while (rs.next()) {
                listname.add(new ListName(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3))
                );
            }

        } catch (Exception e) {
        }
        return listname;

    }
     public void deleteListName(String id) {
        String sql = "DELETE FROM listname WHERE listname.id=?";

        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
        }

    }
     public ListName findListNameById(String id){
         
        String sql = "select * FROM listname WHERE listname.id=?";

        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, id);
            rs = ps.executeQuery();
            while (rs.next()) {
                return new ListName(rs.getInt(1),
                        rs.getString(2),
                        rs.getString(3)
                );

            }
        } catch (Exception e) {
        }
        return null;
     }
     
     
      public ListName updatePost(ListName listName) {
        String sql = "UPDATE listname SET listname.type =?, listname.image=? WHERE listname.id=?";
        try {
            // connect
            con = new ConnectDB().condb();
            // sql
            ps = con.prepareStatement(sql);
            ps.setString(1, listName.getType());
            ps.setString(2, listName.getImage());
            ps.setInt(3, listName.getId());



            ps.executeUpdate();
        } catch (Exception e) {
        }

        return listName;
    }

}
