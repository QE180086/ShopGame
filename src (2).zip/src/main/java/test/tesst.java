/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package test;

import dao.AccountDAO;
import dao.ListNameDAO;
import dao.ManagementDAO;
import dao.NewsDAO;
import dao.PaggingDAO;
import dao.ProductDAO;
import java.util.List;
import model.ListName;
import model.Message;
import model.Post;
import model.Product;
import model.User;

/**
 *
 * @author nguye
 */
public class tesst {
    public static void main(String[] args) {
        
        PaggingDAO pgd = new PaggingDAO();
        ProductDAO prd = new ProductDAO();
        ManagementDAO md = new ManagementDAO();
        NewsDAO nd = new NewsDAO();
        AccountDAO a = new AccountDAO();
        System.out.println("------------hhhhhhhhhhhh--------");
        
 
    }
}
