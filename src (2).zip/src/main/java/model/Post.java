/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author nguye
 */
public class Post {
    private int id;
    private String title;
    private String image;
    private Date created_at;
    private String link;
    private String content;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }
    

    public Post() {
    }

    public Post(int id, String title, String image, Date created_at,String link, String content) {
        this.id = id;
        this.title = title;
        this.image = image;
        this.created_at = created_at;
         this.link = link;
        this.content = content;
    }

    @Override
    public String toString() {
        return "Post{" + "id=" + id + ", title=" + title + ", image=" + image + ", created_at=" + created_at + ", link=" + link + ", content=" + content + '}';
    }
    
    
    
}
