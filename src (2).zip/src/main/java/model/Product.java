/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Date;

/**
 *
 * @author nguye
 */
public class Product {

    private int id;
    private String type;
    private String username;
    private String password;
    private int hero;
    private int skin;
    private String rank;
    private double price;
    private String image;
    private Date created_at;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHero() {
        return hero;
    }

    public void setHero(int hero) {
        this.hero = hero;
    }

    public int getSkin() {
        return skin;
    }

    public void setSkin(int skin) {
        this.skin = skin;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }



    public Product() {
    }

    public Product(int id, String type,String username, String password, int hero, int skin, String rank, double price, String image, Date created_at, String name) {
        this.id = id;
        this.type = type;
        this.username = username;
        this.password = password;
        this.hero = hero;
        this.skin = skin;
        this.rank = rank;
        this.price = price;
        this.image = image;
        this.created_at = created_at;
        this.name = name;
    }

    @Override
    public String toString() {
        return "Product{" + "id=" + id + ", type=" + type + ", username=" + username + ", password=" + password + ", hero=" + hero + ", skin=" + skin + ", rank=" + rank + ", price=" + price + ", image=" + image + ", created_at=" + created_at + ", name=" + name + '}';
    }

  
    

    

}
